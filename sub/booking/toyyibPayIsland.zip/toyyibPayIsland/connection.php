<?php

$host = "localhost";
$user = "root";
$pass = "";
$database = "etourmersing";


    $conn = new mysqli($host, $user, $pass, $database);

    if (!$conn){
        die('connection failed:'.mysqli_connect_error());

    }else{
        $conn->set_charset('utf8mb4');
        echo '<script>console.log("connection passed")</script>';
    }
?>